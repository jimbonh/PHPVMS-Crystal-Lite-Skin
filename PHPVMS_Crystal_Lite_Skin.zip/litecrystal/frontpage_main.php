<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>

<?php /* // Crystal Lite Skin, by Jim L. and Heritage VA 2/13/2020 /////////////////////////////////////////////////////
         // We recommend leaving all of the full-screen settings alone, do not use the div class="container", as this
         // Skin is NOT setup for that, nor will you have room for all of the Side Panels on the frontpage of the system
		 // This will render the skin/template useless, unless you are 100% sure of what your doing, and as 
		 // Always, Backup it UP !!!
		 // */ ?>

<div class="full-screen" style="margin-right:14px;"> 
<div class="row">
<div class="col-md-9">
<!--actual panels start here -->
<div class="panel-group">
<div class="panel panel-primary">
<div class="panel-heading"><p style="font-size:14px;">VA News Center</p></div>
<div class="panel-body"><?php MainController::Run('News', 'ShowNewsFront', 1); ?><br />
<h3>Live Flight Map</h3>
<?php MainController::Run('ACARS', 'index'); ?></div>
<div class="panel-footer" style="border:1px solid #9F9F9F;">Stay Up to Date with Our News & Who's Flying Today.</div>
  </div><!--panel -->
  
<div class="panel panel-primary">
 <div class="panel-heading"><p style="font-size:14px;">Upcoming</p></div>
 <div class="panel-body"><?php include('upcoming_dep.php'); ?></div>
 <div class="panel-footer" style="border:1px solid #9F9F9F;">The Latest Bids Live</div>
   </div>           
    </div><!--col 9-->
    
<div class="col-md-3">          

<div class="panel panel-primary">
<div class="panel-heading"><p>Pilots Online</p></div>
	<div class="panel-body">
<?php
$usersonline = StatsData::UsersOnline();
$guestsonline = StatsData::GuestsOnline();
?>		
                     
		 <?php  
$shown = array();
foreach($usersonline as $pilot)
{
if(in_array($pilot->pilotid, $shown))
continue;
else
$shown[] = $pilot->pilotid;
echo '<div style="font-size:14px;">';
echo "<p>";
echo '<img src="'.Countries::getCountryImage($pilot->location).'" width="28" alt="'.Countries::getCountryName($pilot->location).'" />-';
/*echo PilotData::GetPilotCode($pilot->code, $pilot->pilotid). ' - ' .$pilot->firstname . ' ' . $pilot->lastname; */
echo PilotData::GetPilotCode($pilot->code, $pilot->pilotid). '-' .$pilot->firstname;
/* echo " {$pilot->firstname} {$pilot->lastname} {$pilot->rank}<br />"; */
echo "<strong><em> {$pilot->rank}</em></strong><br />"; 
echo "</p>";
echo "</div>";
}
 ?>
 
  <?php
	$userCount = 0;
	$staffCount = 0;
	$guestsonline = count(StatsData::GuestsOnline());
    $pilots = StatsData::UsersOnline();
	foreach($pilots as $staff){
		if(PilotGroups::group_has_perm(PilotGroups::getUserGroups($staff->pilotid), ACCESS_ADMIN) == true)
			{
			$staffCount++;
				}else{
		   $userCount++;
		 }
		 }
				?>
<p style="font-size:14px; color:#F4880F;">                
Guests Online: <?php echo $guestsonline; ?></p>
      
      </div>
      </div><br /><!--panel -->

<div class="panel panel-primary">
<div class="panel-heading"><p>Online Map</p></div>
	<div class="panel-body">
<script type="text/javascript" src="//rf.revolvermaps.com/0/0/7.js?i=5hqbeosl1g1&amp;m=6&amp;c=ff0000&amp;cr1=ffffff&amp;br=16&amp;sx=0" async="async"></script>	
    </div>
      </div><!--panel group--> 
      
<div class="panel panel-primary">
<div class="panel-heading"><p>Recent Reports</p></div>
	<div class="panel-body">
	<?php MainController::Run('PIREPS', 'RecentFrontPage', 5); ?>
    </div>
      </div><!--panel group-->                      


<div class="panel panel-primary">
<div class="panel-heading"><p>Newest Pilots</p></div>
<div class="panel-body">	
	<?php MainController::Run('Pilots', 'RecentFrontPage', 5); ?>
    </div>
      </div><!--panel group-->
      

<div class="panel panel-primary">
<div class="panel-heading"><p>Activity Feed</p></div>
<div class="panel-body">	
	<?php MainController::Run('Activity', 'Frontpage', 5); ?>
    </div>
      </div><!--panel group-->                   
        
        
<div class="panel panel-primary">
<div class="panel-heading"><p><strong>Aircraft Reserved</strong></p></div>
	<div class="panel-body"><?php include('iata_dep.php'); ?></div>
      </div><!--panel group-->
                                  

<div class="panel panel-primary">	
<div class="panel-heading"><p>AirMail</p></div>
<div class="panel-body">
<h4><em><?php MainController::Run('Mail', 'checkmail'); ?></em></h4>
<center>
<p>Stamp Takes you to AirMail</p>
<a href="<?php echo url('/Mail'); ?>"><img src="<?php echo SITE_URL?>/lib/skins/litecrystal/images/mailstamp.png" /></a>
<p>NOTE: You Must be logged In</p></center>
</div>
  </div><!--panel group-->
  
<div class="panel panel-primary">
<div class="panel-heading"><p><strong>UTC Time</strong></p></div>
	<div class="panel-body">
<a href="https://time.is/UTC" id="time_is_link" rel="nofollow"><h3>UTC Time & Date<br />
LIVE :</h3></a>
<hr>
<p style="font-size:14px; font-weight:bold;"><span id="UTC_za00"></span>
<script src="//widget.time.is/en.js"></script>
<script>
time_is_widget.init({UTC_za00:{template:"TIME<br>DATE", date_format:"dayname, monthname dnum, year"}});
</script></p>
    </div>
      </div><!--panel group-->  
                      
         </div><!--close the above MAIN row-->            
	
	<?php
	/* $usersonline also has the list of users -
		really simple example
		
		Or if you're not on the frontpage:
		$usersonline = StatsData::UsersOnline();
		
	
	foreach($usersonline as $pilot)	
	{
		echo "{$pilot->firstname} {$pilot->lastname}<br />";
	}
	*/
	?>
	
</div> <!--Leave alone please, or things WILL go haywire here ///////// -->
