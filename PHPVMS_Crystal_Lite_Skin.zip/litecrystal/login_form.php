<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<style>
  
.main-panel {
  /*  width:100%;
    overflow:hidden; */
}
.main-panel{
   background-image: url(<?php echo SITE_URL?>/lib/skins/litecrystal/images/carrier3.jpg);
    background-size: cover;
	height: 900px;
}
.card-header {
    padding-top:1%;
}
.forgot{
    padding-top: 2.5%;
    padding-bottom: 2.5%;
}
.body {
    background-image: url(<?php echo SITE_URL?>/lib/skins/litecrystal/images/carrier3.jpg);
	background-size: cover;
	height: 900px;
}
.card {
    padding-left: 2%;
    padding-right: 2%;
}
/* The switch - the box around the slider */
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

/* Hide default HTML checkbox */
.switch input {display:none;}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}

.first-icon, .second-icon{
    visibility: hidden;
}
</style>
<br>
<br>
<br>
<div class="full-screen" style="background-image:url(<?php echo SITE_URL ?>/lib/skins/litecrystal/images/carrier3.jpg); height: 600px; background-position: center; background-size:cover; border:8px groove #3377B7; box-shadow: 12px 12px 16px 0px rgba(51,119,183,0.9); margin-top:44px; padding:14px;">
    <nav class="navbar navbar-transparent navbar-absolute">
        <div class="full-screen">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>              
            </div>
            
            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                    
<a href="<?php echo SITE_URL ?>/index.php/registration"><button type="button" class="btn btn-primary">Register Here</button></a>                                                                          
                </ul>
            </div>
        </div>
    </nav> 
       
    
    <div class="row">
        <div class="col-md-4 col-sm-6 col-md-offset-4 col-sm-offset-3">
                    <div class="card">
        <?php
        if(isset($message))
            echo '<div class="alert alert-danger">
            <h4><i class="icon fa fa-exclamation-triangle"></i> Error</h4> '.$message.'</div>';
        ?>

        <div class="login-box-body">
            <div class="card-header">
                <p class="card-title" style="color:white; font-size:18px;"><em>Login Form</em></p>
            </div>

            <form name="loginform" action="<?php echo url('/login');?>" method="post">
                <label style="color:white;">Username</label>
                <div class="form-group has-feedback">
                    <input type="text" name="email" class="form-control" placeholder="Email">
                    <span class="form-control-feedback"></span>
                </div>
                <label style="color:white;">Password</label>
                <div class="form-group has-feedback">
                    <input type="password" name="password" class="form-control" placeholder="Password">
                    <span class="form-control-feedback"></span>
                </div>
                <div class="row">
                    <div class="col-xs-6">
                        <label class="switch">
                        <input type="checkbox" name="remember"><span class="slider round"></span>
                        </label>
                    </div>
                    <div class="col-xs-4">
                        <input type="hidden" name="redir" value="" />
                        <input type="hidden" name="action" value="login" />
                        <input type="submit" class="btn btn-fill pull-right btn-primary" name="submit" value="Lets Go" />
                        </div>
                        
                    <div class="col-xs-2">  
                     <a href="<?php echo url('login/forgotpassword'); ?>" class="btn btn-primary">Forgot password</a></div> 
                    </div>
                </div>
                </div>
            </form>
            
<br>
<br>            
 </div>
 </div>
 </div>
 </div>  
 </div>
 </div>
<br>
<br>
<br>  
<div align="left">
<p style="color:black; font-size:14px; padding-left:74px;"><?php echo date('Y'); ?> &copy; &trade; <?php echo SITE_NAME; ?></p></div>
            </div></body>
            <br>
            <br>
            <br>