
<?php  /*if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?> /// This is now POINTLESS in todays Browsers/// */ ?>

<!--// For Non Bootstrap users use regular format if using any Bootstrap here //
///// We will start our own custom buttons style here ////////////////////////-->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<br />
<br />
<br />
<div align="center">
<h1>VA Flight Briefing</h1>
<hr>   
</div>
          
<div class="full-screen">
<div align="center">  
<img src="http://www.gcmap.com/map?P=<?php echo $schedule->depicao?>-<?php echo $schedule->arricao?>,&amp;MS=fb&amp;MP=rect&amp;MR=540&amp;MX=720x360&amp;PM=b:star12:red%2b%22%25U%25+%28N%22:red/:black&amp;PC=%23ffa500&amp;PW=2" alt="map" id="map_image" class="map-image" width="920" height="460">
<br />
<br />


<?php 
		# Don't allow overlapping bids and a bid exists
		if(Config::Get('DISABLE_SCHED_ON_BID') == true && $schedule->bidid != 0) {
		?>
			<a id="<?php echo $schedule->id; ?>" class="addbid" 
	href="<?php echo actionurl('/schedules/addbid/?id='.$schedule->id);?>"><button class="btn btn-default"><i class="fa fa-area-chart fa-lg"></i> Add to Bid?</button></a>
		<?php
		} else {
			if(Auth::LoggedIn()) {
			 ?>
				<a id="<?php echo $schedule->id; ?>" class="addbid" 
	href="<?php echo url('/schedules/addbid');?>"><button class="btn btn-default"><i class="fa fa-area-chart fa-lg"></i> Add to Bid?</button></a>
			<?php			 
			}
		}		
		?>
        
</div>

<br>
<hr>
<script src="http://skyvector.com/linkchart.js"></script>
<table width="98%" align="center" cellpadding="0">
	<!-- Flight ID -->
<tr style="background-color: #4A4A4A">
	  <td colspan="2"><center><h4 style="color:white">Operator-Flight Number</h4></center></td>
	</tr>
	<tr>
	  <td colspan="2">
		<center><h4><b><?php echo $schedule->code.$schedule->flightnum; ?></b></h4>
     	  </td>
	</tr>
	
	<tr>
		<td>Departure</td>
		<td>Arrival</td>
	</tr>
    <tr>
	<td><p><b>-<?php echo $schedule->depicao?></b></p></td>
    <td><p><b>-<?php echo $schedule->arricao?></b></p></td>
	</tr>
	
	<!-- Times Row -->
<tr>
		<td>Departure Time</td>
		<td>Arrival Time</td>
	</tr>
	<tr>
		<td width="50%" ><b><?php echo "{$schedule->deptime}"; ?></b></td>
		<td width="50%" ><b><?php echo "{$schedule->arrtime}"; ?></b></td>
	</tr>
	
	<!-- Aircraft and Distance Row -->
	<tr>
	  <td>Aircraft</td>
	  <td>Distance</td>
        </tr>
        <tr>		
		<td width="50%" ><?php echo "{$schedule->aircraft}"; ?></td>
		<td width="50%" ><?php echo "{$schedule->distance}"; ?></td>
	</tr>
	  					           
   <td>
   <div class="separator_left"></div>   
    
<h4>METARS-Weather-Depature-<?php echo $schedule->depicao?></h4><br />
<button onclick="tadsdep()" class="btn btn-primary btn-lg">METARS Departure.(click me)</button>
          <script>
function tadsdep() {
 window.open("http://www.aviationweather.gov/metar/board?ids=<?php echo $schedule->depicao?>&format=expanded", "_blank", "toolbar=no, scrollbars=yes, resizable=yes, top=30, left=40, width=1170, height=580"); 
 } 
</script>  </td>

 <td> 
 <div class="separator_left"></div>
<h4>METARS-Weather-Arrival-<?php echo $schedule->arricao?></h4><br />
<button onclick="tadsarr()" class="btn btn-primary btn-lg">METARS Arrival..(click me)</button>
          <script>
function tadsarr() {
 window.open("http://www.aviationweather.gov/metar/board?ids=<?php echo $schedule->arricao?>&format=expanded", "_blank", "toolbar=no, scrollbars=yes, resizable=yes, top=30, left=40, width=1170, height=580"); 
 } 
</script>  
</td> 
<br />

<br />
<!--Data decoded and in simple format scripted on 9/25/2016-->
<table width="98%" align="center" cellpadding="0">
<td valign="left" width="33%" nowrap="nowrap" >

<h4>TAF-Depature-DECODED-<?php echo $schedule->depicao?></h4><br />
<button onclick="tafdep()" class="btn btn-primary btn-lg">TAF-DeCODED.(click me)</button>
          <script>
function tafdep() {
 window.open("http://www.aviationweather.gov/metar/data?ids=<?php echo $schedule->depicao?>&format=decoded&hours=0&taf=off&layout=off&date0", "_blank", "toolbar=no, scrollbars=yes, resizable=yes, top=20, left=20, width=1170, height=580"); 
 } 
</script>  
</td>
<td valign="left" width="33%" nowrap="nowrap" >
<div class="separator_left"></div>
<h4>TAF-Arrival-DECODED-<?php echo $schedule->arricao?></h4><br />
<button onclick="tafarr()" class="btn btn-primary btn-lg">TAF-DeCODED.(click me)</button>
          <script>
function tafarr() {
 window.open("http://www.aviationweather.gov/metar/data?ids=<?php echo $schedule->arricao?>&format=decoded&hours=0&taf=off&layout=off&date0", "_blank", "toolbar=no, scrollbars=yes, resizable=yes, top=20, left=20, width=1170, height=580"); 
 } 
</script>  </td>
      </table>
      <!--end of TAF decoded script-->
      <br>
<center><p><b>Chart Procedures and Information ( click desired chart for download ) This opens another Tab<br>
Thank You AirNav for the use of your Charts & Downloads</b></p></center>
<table width="98%" align="center">

	<tr>
		<td><h3>Charts for <?php echo $schedule->depicao?></h3></td>
		<td><h3>Charts for <?php echo $schedule->arricao?></h3></td>
	</tr>
	<tr align="center">
		<td width="50%" valign="top">
			<a href="http://www.airnav.com/airport/<?php echo $schedule->depicao?>#ifr" target="_blank">
			<img border="0" src="http://flightaware.com/resources/airport/<?php echo $schedule->depicao?>/APD/AIRPORT+DIAGRAM/png"
				width="437px" height="654px" alt="No chart available" /></a>
		</td>
		<td width="50%" valign="top">
			<a href="http://www.airnav.com/airport/<?php echo $schedule->arricao?>#ifr" target="_blank">
			<img border="0" src="http://flightaware.com/resources/airport/<?php echo $schedule->arricao?>/APD/AIRPORT+DIAGRAM/png" 
				width="437px" height="654px" alt="No chart available" /></a>
		</td>
	
	</tr>
</table>
      <br>
  <h1 style="color:black"><b>Terminal Procedures</b></h1>
  <p style="font-size:16px; color:red;">NOTE:If an airport doesn't show up,please use SkyVector below,this is World Wide.VFR Map is only USA ICAO charts.</p>
<table width="98%" align="center" class="table table-striped table-bordered">

	<tr>
		<td>Interactive Info for <?php echo $schedule->depicao?></td>
		<td>Interactive Info for <?php echo $schedule->arricao?></td>        
	</tr>
	<tr align="center">
    <td width="50%" valign="top">
   <object data="https://www.iFlightPlanner.com/AviationCharts/?Map=terrain&GS=250&Route=<?php echo $schedule->depicao?>" width="597" height="848" /></td>     	
    <td width="50%" valign="top">
   <object data="https://www.iFlightPlanner.com/AviationCharts/?Map=terrain&GS=250&Route=<?php echo $schedule->arricao?>"width="597" height="848"/></td>
   				
	</tr>
</table>

<br />                                                                                    

<div class="separator_auto"></div>
<br />
<table width="98%" align="center">
 <tr align="center">
 <td width="50%" valign="top">
	<object data="http://vfrmap.com/fe?req=get_afd&q=<?php echo $schedule->depicao?>"width="597" height="748"/></td>
        <td width="50%" valign="top">
	<object data="http://vfrmap.com/fe?req=get_afd&q=<?php echo $schedule->arricao?>"width="597" height="748"/></td>
    </tr>
    </table>
                 
<br />
<div class="separator_auto"></div>
<br>
<h1 style="color:black"><b><fa fa-bank fa-lg></i> WXR-LIVE</b></h1>

<div class="row">
<div class="col-md-6">
<iframe src="http://vfrmap.com/fe?req=get_wx&q=<?php echo $schedule->depicao?>" width="597" height="500" style="border:none;"></iframe>
  </div><!--col -->
  
<div class="col-md-6">
<iframe src="http://vfrmap.com/fe?req=get_wx&q=<?php echo $schedule->arricao?>"width="597" height="500" style="border:none;"></iframe>
</div>
  </div><!--row-->
<!--     
<table width="98%" align="center">
<tr>
	<tr>
		<td>WXR-TOPO-CHARTS SYSTEM FOR DEPARTURE <?php echo $schedule->depicao?></td>
		<td>WXR-TOPO-CHARTS SYSTEM FOR ARRIVAL <?php echo $schedule->arricao?></td>        
	</tr>
	<tr align="center">   
		<td width="50%" valign="top" style="border:1px solid #000000; padding:12px;">
	<object data="http://vfrmap.com/fe?req=get_wx&q=<?php echo $schedule->depicao?>" width="597" height="400"/></td>    
        <td width="50%" valign="top">
	<object data="http://vfrmap.com/fe?req=get_wx&q=<?php echo $schedule->arricao?>"width="597" height="400"/></td>						
	</tr>
</table>-->
<br>
<br>
<br> 
                                

<!--Search skyvector for airport info -->
<div class="container" style="color: #000000; width:98%;">
<p style="font-size:18px;">NOTE: If a base doesn't show up on the normal listings, please use Sky Vector Buttons. Sky Vector "WILL" show any and all<br />
Airport Listings with many other features in the USA. It also will show most airports accross the world. The buttons will open up in another popup window.</p></div>

<br />
<center>
<p style="color:black; font-size:24px;">SkyVector Charts for <?php echo $schedule->depicao?></p>
<hr class="small">
<a href="https://skyvector.com/search/site/<?php echo $schedule->depicao?>" onClick="javascript:void window.open('https://skyvector.com/search/site/<?php echo $schedule->depicao?>','1464342149668','width=1280,height=640,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=30,top=15');return false;">
<button class="btn btn-primary btn-lg">Open with SkyVector</button></a>
<hr>
<p style="color:black; font-size:24px;">SkyVector Charts for <?php echo $schedule->arricao?></p>
<hr class="small">
<a href="https://skyvector.com/search/site/<?php echo $schedule->arricao?>" onClick="javascript:void window.open('https://skyvector.com/search/site/<?php echo $schedule->arricao?>','1464342149668','width=1280,height=640,toolbar=0,menubar=0,location=0,status=1,scrollbars=1,resizable=1,left=30,top=15');return false;">
<button class="btn btn-primary btn-lg">Open with SkyVector</button></a>
</center>
<hr>
<!--https://skyvector.com/search/site/KPSM		-->
	<!-- Route -->
	<tr>
	  <td colspan="2"><h4>Route Comments</h4></td>
	</tr>
	<tr>
		<td colspan="2">
		<?php 
		# If it's empty, insert some blank lines
		if($schedule->route == '')
		{
			echo '<br /> <br /> <br />';
		}
		else
		{
			echo strtoupper($schedule->route); 
		}
		?>
		</td>
	</tr>
	
	<!-- Notes -->
	<tr>
	  <td colspan="2"><h4>Notes - Comments</h4></td>
	</tr>
	<tr>
		<td colspan="2" style="padding: 6px;">
		<?php 
			# If it's empty, insert some blank lines
			if($schedule->notes == '')
			{
				echo '<br /> <br /> <br />';
			}
			else
			{
				echo "{$schedule->notes}"; 
			}
		?>
		</td>
	</tr>
	
	
</table>

<table class="table table-striped table-bordered">
<!--<table width="98%" align="center" padding="2" border="1"> -->
<tr>
	<td>Additional Data provided by FlightAware, Departure Schedule to Arrival Schedule "Live".</td>
</tr>
<tr>    
<td><a href="http://flightaware.com/analysis/route.rvt?origin=<?php echo $schedule->depicao?>&destination=<?php echo $schedule->arricao?>"target="_blank">
  <button class="btn btn-default">Flightaware Additional Data</button></a></td>
</tr>
</table>
<br />
<br />
</div>

<div align="right" style="font-size: small; font-color: black; ">Copyright &copy;<?php echo date('Y'); ?>
       <a href="#" target="_blank"><b><?php echo SITE_NAME ?></a></div>
<br />
</div>
