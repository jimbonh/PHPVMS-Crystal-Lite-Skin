<?php /* if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } */ ?>
<br>
<br>
<br>

<h3>PHPVMS II <em style="color:red;">Schedule Search</em> &trade;</h3>
<!--<form id="form" action="<?php echo url('/schedules/view');?>" method="post"> -->

    <form id="form" type="hidden" method="post" action="<?php echo url('/schedules');?>">
    <div class="row">
    <div class="col-md-3">	
		<p>Select your departure airport:</p>
		<select id="depicao" name="depicao" class="form-control">
		<option value="">Select All</option>
		<?php
		if(!$depairports) $depairports = array();

		foreach($depairports as $airport) {
			echo '<option value="'.$airport->icao.'">'.$airport->icao
					.' ('.$airport->name.')</option>';
		}
		?>

		</select>
		<!--<input type="submit" name="submit" value="Find Flights" />-->
	</div>
    
      
     
     
    <div class="col-md-3"> 	
		<p>Select your arrival airport:</p>
		<select id="arricao" name="arricao" class="form-control">
			<option value="">Select All</option>
		<?php
		if(!$depairports) $depairports = array();

		foreach($depairports as $airport) {
			echo '<option value="'.$airport->icao.'">'.$airport->icao
					.' ('.$airport->name.')</option>';
		}
		?>

		</select>
		<!--<input type="submit" name="submit" value="Find Flights" />-->
	</div>
     
      
      
      
    <div class="col-md-3">	
		<p>Select aircraft:</p>
		<select id="equipment" name="equipment" class="form-control">
			<option value="">Select aircraft</option>
		<?php
		if(!$aircraft_list) {
            $aircraft_list = array();
		}

		foreach($aircraft_list as $aircraft) {
			echo '<option value="'.$aircraft->name.'">'.$aircraft->name.'</option>';
		}

		?>
		</select>
		<!--<input type="submit" name="submit" value="Find Flights" />-->
	</div>
     
     
      
   
    <div class="col-md-3">    
        <p>Select An Airline</p>
        <select id="airlines" name="airlines" class="form-control">
        <option value="">Select Airline</option>
        <?php
        if(!$airlines) $airlines = array();
        foreach ($airlines as $airline) {
            echo '<option value="'.$airline->code.'">'.$airline->name.'</option>';
        }
        ?>

        </select>

       <!--/ defaults yukk <input type="submit" name="submit" value="Find Flights" /> -->
    </div>     

	<div class="col-md-3">
    <div style="height:34px;"></div>
    <div class="separator_left" style="height:1px;"></div>
		<p>Select Distance:</p>
		<select id="type" name="type" class="form-control">
			<option value="greater">Greater Than</option>
			<option value="less">Less Than</option>
		</select>
		<input type="text" class="form-control" name="distance" value="" />
        <br>		
	</div>
</div> <!-- / row /-->

<input type="hidden" name="action" value="findflight" />
<div align="center"><input type="submit" name="submit" class="btn btn-primary" value="Find Flights" /></div>
</form>

