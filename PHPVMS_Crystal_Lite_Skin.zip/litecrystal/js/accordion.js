// JavaScript Document Accordion Collapse made easy by Jim L. 
// Copyright 2019 and Trademarked under WebMastersSolutions Inc. All rights Reserved
// Under TM & Registered RSA bylaws Express Permission is required at support@seairtranport.net
//

var acc = document.getElementsByClassName("accordion"); // name can be changed if so use <button class="mynewName">Dropdown</button>
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight){
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}