<!doctype html>
<html>
<head>
<meta charset="utf-8">
<!--=== Internet Expolorer Compatible====-->
<!--[if IE]><meta http-equiv="x-ua-compatible" content="IE=9" /><![endif]-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/png" href="<?php echo SITE_URL?>/lib/skins/litecrystal/favicon.png">
<meta name="description" content="">
<meta name="author" content="">

<title><?php echo SITE_NAME; ?></title>

<!--====Added on 2/12/2020 Bootstrap ====-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--===Custom Site scripts====-->  
<link rel="stylesheet" media="all" type="text/css" href="<?php echo SITE_URL?>/lib/skins/litecrystal/styles2.css" />
<link href="<?php echo SITE_URL?>/lib/skins/litecrystal/css/menubot.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="<?php echo SITE_URL ?>/lib/skins/litecrystal/js/bookmarkscroll.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.15.0/popper.min.js"></script>
<script src="<?php echo SITE_URL?>/lib/skins/litecrystal/js/jquery-3.2.1.min.js"></script>  <!--///THE HEART OF phpvms do NOT delete this or Bids won't work!! / -->        
        <!--===== Google Icons Calls =====-->
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
        
        <!--===== Font Awesome all versions =====-->        
        <link href="http://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>

<?php /* unremark to enable prevention of any right clicks on the web site ///////    
<script language=JavaScript> var message="Copyright Protected 2020"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script> */ ?>

    
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links
  $("a").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
});
</script>
<style>
body, html, .main { /* Part of above for smooth scrolling script */
  height: 100%;
}

section {
  min-height: 100%;
}
</style>


<?php 
/* This is required, so phpVMS can output the necessary libraries it needs */
echo $page_htmlhead; 
?>

<?php /*Any custom Javascript should be placed below this line, after the above call */ ?>

<!--my script for recaptcha before closing head MUST HAVE THIS-->
    <script src='https://www.google.com/recaptcha/api.js'></script>

 <!--Start style for menu system I've created "Menu Navigation" system, this is HIGHLY Customizable,colors,shadows etc.... -->
<style>

.dropbtn {
    
    background-color: #3377B7; 
    color: white;
    padding: 8px; 	
    font-size: 14px;
	min-width: 119px;
    border: none;
    cursor: pointer;
	top:0px;

}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
	font-size: 14px;
    position: absolute;
    background-color: #323232;
    min-width: 228px;
   /* box-shadow: 16px 16px 18px 0px rgba(124,154,177,0.9); // unremark if you want a shadow around the menus */
    z-index: 1;
}

.dropdown-content a {
    color: white;   
    padding:8px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {
background-color: #F3AD4B;
}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #323232;
}

 </style> 
<!-- end style colors etc., for menus here-->

</head>
<body>
<?php
/* This should be the first thing you place after a <body> tag
	This is also required by phpVMS */
echo $page_htmlreq;
?>
<a id="top"></a>
 <!--div id body-->
<div class="full-screen">
<nav class="navbar navbar-fixed-top" style="margin-left:44px; margin-right:44px;">

<div class="dropdown">
<a href="<?php echo SITE_URL ?>/index.php"><button class="dropbtn">Home</button></a>
</div>

<div class="dropdown">
  <button class="dropbtn">Operations</button>
  <div class="dropdown-content">
    <a href="<?php echo url('/pilots') ?>">Pilot Roster <i class="fab fa-black-tie fa-lg"></i></a>      
    <a href="<?php echo url('/news') ?>">VA Frontpage News</a>    
    <a href="<?php echo url('/finances'); ?>">VA Finances</a>
    <a href="<?php echo url('/activity') ?>">Activity Feeds</a>
    <a href="#">Reserved</a> 
    <a href="#">Reserved</a>        
    
    </div>
    </div>
    

<div class="dropdown">
  <button class="dropbtn">Tower</button>
  <div class="dropdown-content">
<a href="<?php echo url('/schedules'); ?>">PHPVMS Schedule Search</a>
<a href="#">Reserved</a>
<a href="#">Reserved</a>
<a href="#">Reserved</a>
<a href="#">Reserved</a>
</div>
</div>

<div class="dropdown">
  <button class="dropbtn">Hanger</button>
  <div class="dropdown-content">
  <a href="#">Reserved</a>
  <a href="#">Reserved</a>
  <a href="#">Reserved</a>
  <a href="#">Reserved</a>
  <a href="#">Reserved</a>
</div>
</div> 

<div class="dropdown">
  <button class="dropbtn">CrewCenter</button>  
  <div class="dropdown-content">
  <?php if(Auth::LoggedIn()) { ?>
        <a href="<?php echo url('/profile'); ?>">My Pilot Center</a>       
        <a href="<?php echo url('/pireps'); ?>">View My PIREPS</a>
        <a href="<?php echo SITE_URL?>/index.php/schedules/bids">View My Bids</a>
        <a href="<?php echo SITE_URL?>/index.php/pireps/routesmap">View My Route Map</a>
        <a href="<?php echo SITE_URL?>/index.php/profile/stats">View My Stats</a>
        <a href="<?php echo SITE_URL?>/index.php/profile/badge">View My Badge</a>      
        <a href="<?php echo SITE_URL?>/index.php/downloads">View Downloads</a>
  <?php } else { ?>
  <p style="color:white; padding:8px;"><em>You Must be Logged in to View your Systems CrewCenter, Please Login First.</em></p>
  <?php } ?>  
</div>
</div>
 
  
<div class="dropdown">
<?php if(Auth::LoggedIn()) { ?>
<a href="<?php echo url('/logout'); ?>"><button class="dropbtn">Log Out</button></a>
<?php } else { ?> 
<a href="<?php echo url('/login'); ?>"><button class="dropbtn">Log In</button></a>
<a href="<?php echo url('/registration'); ?>"><button class="dropbtn">Signup</button></a>
<?php } ?>     
      </div> 
      
<?php 
if(Auth::LoggedIn())
{
	if(PilotGroups::group_has_perm(Auth::$usergroups, ACCESS_ADMIN))
	{ 
	?>
<div class="dropdown">
<button class="dropbtn">Admin</button>
<div class="dropdown-content">

<div class="dropdown-divider"></div>
<a href="<?php echo SITE_URL ?>/admin/index.php/pilotadmin/pendingpilots">Pending Pilots (<?php echo count(PilotData::GetPendingPilots())?>)</a>
<a href="<?php echo SITE_URL ?>/admin/index.php/pirepadmin/viewpending">PIREPS Pending <?php echo  count(PIREPData::GetAllReportsByAccept(PIREP_PENDING))?></a>
<div class="dropdown-divider"></div>
<a href="<?php echo SITE_URL ?>/admin">Admin Panel</a>
</div>
</div>
<?php } } ?>             
  
    </nav> <!--close top fixed Nav bar--> 
    </div><!--full screen--> 
	
	
<!-- beaware that if you change the next 7 lines, this will throw off all of the alignment that match the 
//// frontpage_main.php file on the other side. We do not recommend that you mess with this thanks -->

	<?php
	echo '<div class="full-screen" style="margin-left:64px; margin-right:64px;">';	// customized for the Crystal Lite skin only
	echo '<div style="padding-top:94px;">';
	echo $page_content;
	echo '</div>';
	echo '</div>';
	?>
			        	            
    <div class="full-screen" style="margin-left:34px; margin-right:34px;"> <!-- full screen gives you more options for adding things to any area///////-->
    <hr>
	<p>copyright &copy; - <?php echo date('Y') ?> - <?php echo SITE_NAME; ?><br />
	<!-- Please retain this!! It's part of the phpVMS license. You must display a
			"powered by phpVMS" somewhere on your page. Thanks! -->
	<a href="http://www.phpvms.net" target="_blank">powered by phpVMS</a></p>    
    <a name="bottom"></a>
    <nav class="navbar navbar-fixed-bottom" style="text-align:right; padding-right:6px;"> <!--// Fixed Icon on the bottom right hand corner for scrolling ///-->
    <a href="#top"><i class="fas fa-chevron-circle-up fa-4x"></i></a>
    </nav>
	</div>        
</div> 

</body>
</html>