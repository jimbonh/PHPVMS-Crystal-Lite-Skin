<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<br>
<br>

<?php
$lastbid = SchedulesData::GetAllBids();
if (count($lastbid) > 0)
{ ?>


<table width="100%" border="1">
<center><h3 style="font-size:32px;"><em>Upcoming Departures</em></h3></center>

<style>
.parallax3 { 
    /* The image used */
    /*background-image: url("<?php echo SITE_URL?>/lib/skins/litecrystal/images/sky2.jpg"); */
	background-color:#3377B7;

    /* Set a specific height */
    height: 100px; /* was 100px */

    /* Create the parallax scrolling effect */
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
	
}

</style>
<br>
<tr>
<thead class="parallax3" style="color:#ffffff; font-size:14px;">

<th><div align="center">Flight Number</div></th>
<th><div align="center">Pilot</div></th>
<th><div align="center">Departure</div></th>
<th><div align="center">Arrival</div></th>
<th><div align="center">Flight Duration</div></th>
<th><div align="center">Aircraft</div></th>
<th><div align="center">Registration</div></th>

</thead>
</tr>

<tbody>

<?php

foreach($lastbid as $lastbid)
{
?>

<?php
$flightid = $lastbid->id
?>
<style>
td {
font-size:14px;
}
</style>
<td height="25" width="10%" align="center"><?php echo $lastbid->code; ?><?php echo $lastbid->flightnum; ?></td>
<?php
$params = $lastbid->pilotid;

$pilot = PilotData::GetPilotData($params);
$pname = $pilot->firstname;
$psurname = $pilot->lastname;
?>
<td height="25" width="10%" align="center"><?php echo $pname; ?> <?php echo $psurname; ?></td>
<td height="25" width="10%" align="center"><?php echo $lastbid->depicao; ?></td>
<td height="25" width="10%" align="center"><?php echo $lastbid->arricao; ?></td>
<td height="25" width="10%" align="center"><?php echo $lastbid->flighttime; ?> hours</td>
<td height="25" width="10%" align="center"><?php echo $lastbid->aircraft; ?></td>
<td height="25" width="10%" align="center"><?php echo $lastbid->registration; ?></td>

</tr>

<?php
}
} else { ?>

<h3>There Are No Upcoming Departures!</h3>

<?php
}
?>
</thead>
</tbody>
</table>
</div> 
