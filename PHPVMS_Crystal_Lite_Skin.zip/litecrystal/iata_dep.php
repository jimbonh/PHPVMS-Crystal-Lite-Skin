<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
<br>

<?php
$lastbid = SchedulesData::GetAllBids();
if (count($lastbid) > 0)
{ ?>

<?php

foreach($lastbid as $lastbid)
{
?>

<?php
$flightid = $lastbid->id
?>

<?php
$params = $lastbid->pilotid;

$pilot = PilotData::GetPilotData($params);
$pname = $pilot->firstname;
$psurname = $pilot->lastname;
?>

<h3><?php echo $lastbid->aircraft; ?><br />
<?php echo $lastbid->registration; ?></h3>

<?php
}
} else { ?>

<h3>No Reservations</h3>

<?php
}
?>


