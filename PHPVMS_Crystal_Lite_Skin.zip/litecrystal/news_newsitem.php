<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>

<div style="height:44px;"></div>
<div class="separator_auto"></div>

<h4 style="color:red;"><em><?php echo $subject;?></em></h4>
<p>Posted by <?php echo $postedby;?> on <?php echo $postdate;?></p>
<p><?php echo html_entity_decode($body);?></p>
<hr>  