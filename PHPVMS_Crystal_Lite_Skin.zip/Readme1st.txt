**************************************
**************************************
                                    **
Crystal Lite Skin 2/12/2020 v2.3.A  **
                                    **
**************************************
**************************************

Welcome, this is the Crystal Lite skin for phpvms, the original file of course being 
the Crystal Skin by Nabeel !! From way way back when. We have done a few new things to 
It, but keeping it for the most part in its original state, as we all know that this has
Been and always will be an Emergency GO TO, when all else fails, and now it still is even
with the Upgrades and the Re-Vamping of the original Crystal Skin on Install. And to Nabeel
Thanks again for all of your Hard hard work for the phpvms community for sure !!!!!! 
We'd be lost without ya !!

What it is and what its not:::
This is a basic simple, but very clean template for phpvms, no bells no whistles.
However, this has extreme potential to be something you want, the door is wide open
for those who like to mess around with some coding. REMEMBER -- Always Backup the Original Files !!
This has been designed with today's modern Browsers in mind.

---------------------------------------------------------------------------------------------------
v2.3.A Features::
2/09/2020
Whats been added - Upgraded from XHTML to HTML5 coupled with and added to; Bootstrap 3.3.7 !

2/01/2020
Added Upcoming Departures and Aircraft Reserved Modules "Customized 100%"

2/2/2020
Added Dropdown Hover Menu Navbar that is "FIXED" to the top on any scroll
      Completely customizable for colors,shadows and much more !

2/3/2020
Added Fixed Scroll to Top Icon bottom right hand corner for all page scrolling

2/4/2020
Re-vamped the frontpage_main.php system file, and the style.css files for a cleaner look with Bootstrap
Added Menu system, re-configured all of the layout.php file for a much larger screen look for small & Large Screens.
Reconfigured the php content call so the rest of the layout file doesn't show up at the same time .
// Tested on the following //
Google Chrome::
FireFox::
Waterfox::
Opera::

2/4/2020
Fixed and re-designed the entire html Columns and Rows sections for todays Internet Browsers,
Added new scripting and arrangements, and Thanks flyalaska, proavia, and all my friends for your HELP!

2/5/2020
Converted the ACARS Main Flight Tracking map to Leaflet
Converted the Routes / Schedules Map to Leaflet
NOTE NOTE NOTE ::: This is all included in the install/upload, you DO NOT HAVE TO DO ANYTHING !


2/13/2020
Final testing stages were all successful on another Server and Site !!!!!
------------------------------------------------------------------------------------------------------

Requirements *****************************
This is NOT for TPL versions of phpvms, only phpvms php file format systems.
Server PHP version of 5.3.xx to 5.6.xx, this has NOT been tested with the release of 7.2 or the latest
Release of phpvms 7.2 by proavia from the forums. 
We highly recommend Server PHP version of 5.6.30 to 5.6.xx
Access to an FTP Manager for file uploads, we Recommend FileZilla !!!!
PHPVMS Admin Access
Do Not alter the file folder structures, or the included files unless you absolutely know what your doing.
this has been done for the Crystal Lite skin already !
The folder lives in mywebsite.com/litecrystal/ 
Please don't change the name of the folder, leave intact the way it is.
Enclosed is a PDF file Doc, and of course this file .
******************************************

***************
**The Install**
***************
Leaving intact the structure of this, just simply upload the /litecrystal folder to ;
http://mysite.com/lib/skins/*.* of your phpvms install.
All the work is already done for you !!!
Go to the Admin Panel, you should see the name litecrystal under of course site settings.
Click it, and view it, as mentioned this Works period, and has been throughly tested. We Highly
Recommend before closing your Admin CP out, that you right click "View My Site" and open up your
Site in another Tab to make sure everything is OK ! Obviously if its not, then you have the Option
because you remained in the Admin CP, of changing it back to its original state. 
WE HIGHLY RECOMMEND THE ABOVE PROCEDURE !
All the colors may be changed as mentioned, this is using Bootstrap now, so "primary", "default", "warning", 
"info", "danger", "secondary" are now part of the system via/bootstrap. This includes all of the"Panels".
Menu colors can be changed at your will, along with adding border radius's and shadows of course via/html5

In closing, this is a basic template, but is very open for changes. This template is "AS IS", no warrentys, 
No Nothing....however, I am around to help those who need it if I have the time, ya all can reach me in the
PHPVMS Forums, "Heritage1".
Enjoy, and see you in the "Air" or around Duh Boards !
******************************************************

Jim L. Owner of Heritage Virtual Airlines, since; 2003 (copyright(c)).
http://heritageairlines.com &
http://heritageairlines.com/hva  (beta test site).

******************************************************

